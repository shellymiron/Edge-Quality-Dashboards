
 # OCP-EDGE-4.3 - Quality Dashboard:
  
  https://docs.google.com/spreadsheets/d/1yb3rdWetfIy03cjHo-KLPbTpoKagpGq7EEULHJyd2do/edit#gid=0

 # OCP-EDGE-4.4 - Quality Dashboard:
 
  https://docs.google.com/spreadsheets/d/172_fFzQUP5lpsCUyIxmzJ-gi1XA0dT0xgJ-KdbHa0bQ/edit#gid=0
 
 # OCP-EDGE-4.5 - Quality Dashboard:
  
  https://docs.google.com/spreadsheets/d/1h_zTJmcLpVPp359MFYVUO2-5U0Jxi4WbE2y1HwBLLe0/edit#gid=0
  
 # OCP-EDGE-4.6 - Quality Dashboard:

  https://docs.google.com/spreadsheets/d/1LLMXTNiNJCsfVcpsJkkowFxOUsiiU_60ZZ8js2crI2I/edit#gid=0

# <h3>TO-DO LIST (21.04.2020): </h3>

  - ****(DONE) Reset unwanted rows when re-run the script all over again
  - ****(DONE) Fillter by target release => ('ALL', 'all', '' for all bugs) or (4.3.0, 4.4.0 ... per target)
    ****(DONE)sub task -> try to see if we can make it interactive - we can't, put sheet build filter.
  - ****(DONE) Make another tabs(sheets) to other pillars: CNF, EcoSystem, Managment
  - ****(DONE) Make all the bugs to be in status: NEW, MODIFIED, POST, ASSIGNED and not on ON_QA
  - ****(DONE)Filltering by name of QA contact - need to discuss if a listener is an option
  - ****(DONE) Add column 'Assignee' => pay attention that this column changed to 'QA contact' 
  - ****(DONE) Sort by PM score - we disabled this feature, now we need it back
  - ****(Half Done) Enable the statistics functions and delete redundant ones - 
           Fields missed: verification rate, defect bug 
  - ****(DONE) Target Release Column added to the sheets - filter by this column.
  - ****(Half-DONE) Remove irrelevant code 
  

