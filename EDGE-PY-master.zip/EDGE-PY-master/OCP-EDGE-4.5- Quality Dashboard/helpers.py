from __future__ import division, print_function

# !/usr/bin/env python
import datetime
import ssl

import psycopg2
from config import *

conn = psycopg2.connect(
    "dbname=public user=smiron password=M24shellybzx088! host=virtualdb.engineering.redhat.com port=5432")

conn.set_isolation_level(0)
cursor = conn.cursor()

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

# Global variables
PM_SCORE_QUERY_CELL = 9
VERIFICATION_RATE_WEEKS_NUM = 8

# Take the place of the target the user choose
TARGET_RELEASE = g.get_cell_value(4, 10)
VERSION = '4.5'
TARGET_R = '4.5'


def sort_by_pm_score(bugs):
    return sorted(bugs, key=lambda x: int(x[PM_SCORE_QUERY_CELL]), reverse=True)


''' ##################################################################################################################
                        Backlog By Pillar/Squad - Queries

                        X TARGET : 4.3, 4.3.z. 4.4, 4.4.z, 4.5 
                        X internal white board - Telco
                        X Statuses : NEW, POST, ASSIGNED, MODIFIED
                        X Please don't change the order of the arguments in the SELECT sentences - there is
                          a logical reason behind this order.

###################################################################################################################'''


def get_telco_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = ''' SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                    FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                         p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                         ON p2.USERID = bugs.ASSIGNED_TO,
                         Bugzilla.products products,
                         Bugzilla.components components,
                         Bugzilla.bugs_release rel
                    WHERE bugs.component_id = components.id
                         and bugs.product_id = products.id
                         and rel.BUG_ID = bugs.BUG_ID
                         and rel."VALUE" LIKE '%{}%'
                         and bugs.CF_INTERNAL_WHITEBOARD LIKE '%Telco%'
                         and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                         'MODIFIED', 'ON_DEV','ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                        p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                        ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                        Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id
                         and rel."VALUE" LIKE '%{}%'
                         and bugs.QA_CONTACT = profiles.userid
                         and bugs.ASSIGNED_TO = profiles.userid
                         and bugs.product_id = products.id
                         and rel.BUG_ID = bugs.BUG_ID
                         and bugs.VERSION LIKE '%{}%'
                         and CF_INTERNAL_WHITEBOARD LIKE '%Telco%'
                         and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                         'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET, OCP_VERSION)

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_deployment_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                        p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                        ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                        Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                         and bugs.QA_CONTACT = profiles.userid 
                         and bugs.product_id = products.id 
                         and CF_INTERNAL_WHITEBOARD LIKE '%Telco:%Deployment%'  
                         and rel.BUG_ID = bugs.BUG_ID
                         and rel."VALUE" LIKE '%{}%'
                         and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                         'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                          bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                          bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                        p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                        ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                        Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                         and rel."VALUE" LIKE '%{}%' 
                         and bugs.QA_CONTACT = profiles.userid 
                         and bugs.product_id = products.id 
                         and rel.BUG_ID = bugs.BUG_ID 
                         and bugs.VERSION LIKE '%{}%'
                         and CF_INTERNAL_WHITEBOARD LIKE '%Telco:%Deployment%' 
                         and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                         'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_deploy_installer_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                       FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                            p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                            ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                            Bugzilla.components components, Bugzilla.bugs_release rel
                       WHERE bugs.component_id = components.id 
                             and bugs.QA_CONTACT = profiles.userid 
                             and rel.BUG_ID = bugs.BUG_ID
                             and bugs.product_id = products.id 
                             and rel."VALUE" LIKE '%{}%'
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Deployment,%Squad:Installer%'  
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                       FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                        p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                        ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                            Bugzilla.components components, Bugzilla.bugs_release rel
                       WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Deployment,%Squad:Installer%' 
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_deploy_network_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                        FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                        WHERE bugs.component_id = components.id 
                              and bugs.QA_CONTACT = profiles.userid 
                              and bugs.product_id = products.id
                              and rel.BUG_ID = bugs.BUG_ID 
                              and rel."VALUE" LIKE '%{}%'
                              and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Deployment,%Squad:Networking%'
                              and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                              'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                        FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                        p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                        ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                        WHERE bugs.component_id = components.id 
                              and rel."VALUE" LIKE '%{}%' 
                              and bugs.QA_CONTACT = profiles.userid 
                              and bugs.product_id = products.id 
                              and rel.BUG_ID = bugs.BUG_ID 
                              and bugs.VERSION LIKE '%{}%'
                              and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                              'MODIFIED', 'ON_QA', 'ON_DEV') 
                              and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Deployment,%Squad:Networking%' ''' \
                                .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_deploy_integration_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                            FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                                 p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                                 ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                                 Bugzilla.profiles profiles,
                                 Bugzilla.components components, Bugzilla.bugs_release rel
                            WHERE bugs.component_id = components.id 
                                  and bugs.QA_CONTACT = profiles.userid 
                                  and bugs.product_id = products.id
                                  and rel.BUG_ID = bugs.BUG_ID 
                                  and rel."VALUE" LIKE '%{}%'
                                  and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Deployment,%Squad:Integration%'
                                  and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                                  'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                          p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                          ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                          Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                          and rel."VALUE" LIKE '%{}%' 
                          and bugs.QA_CONTACT = profiles.userid 
                          and bugs.product_id = products.id 
                          and rel.BUG_ID = bugs.BUG_ID 
                          and bugs.VERSION LIKE '%{}%'
                          and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                          'MODIFIED', 'ON_QA', 'ON_DEV') 
                          and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Deployment,%Squad:Integration%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_deploy_HWManagement_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                           Bugzilla.profiles profiles,
                           Bugzilla.components components, 
                           Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                                  and bugs.QA_CONTACT = profiles.userid 
                                  and rel.BUG_ID = bugs.BUG_ID 
                                  and bugs.product_id = products.id 
                                  and rel."VALUE" LIKE '%{}%' 
                                  and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Deployment,%Squad:HWManagement%'
                                  and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                                  'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                          p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                          ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                          Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                          and rel."VALUE" LIKE '%{}%' 
                          and bugs.QA_CONTACT = profiles.userid 
                          and bugs.product_id = products.id 
                          and rel.BUG_ID = bugs.BUG_ID 
                          and bugs.VERSION LIKE '%{}%'
                          and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                          'MODIFIED', 'ON_DEV', 'ON_QA') 
                          and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Deployment,%Squad:HWManagement%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_management_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                           Bugzilla.profiles profiles, Bugzilla.components components, 
                           Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                           and bugs.QA_CONTACT = profiles.userid 
                           and bugs.product_id = products.id
                           and rel.BUG_ID = bugs.BUG_ID  
                           and rel."VALUE" LIKE '%{}%'
                           and CF_INTERNAL_WHITEBOARD LIKE '%Telco:%Management%'
                           and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                           'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                      FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                      WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:%Management%' '''.format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_management_UI_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                           Bugzilla.profiles profiles, Bugzilla.components components, B
                           Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                           and bugs.QA_CONTACT = profiles.userid 
                           and bugs.product_id = products.id 
                           and rel.BUG_ID = bugs.BUG_ID 
                           and rel."VALUE" LIKE '%{}%'
                           and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%Squad:UI%'
                           and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                           'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE,rel.BUG_ID
                      FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                      WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%Squad:UI%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_mgm_LifeCycle_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                           Bugzilla.profiles profiles, Bugzilla.components components, 
                           Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                           and bugs.QA_CONTACT = profiles.userid 
                           and bugs.product_id = products.id
                           and rel.BUG_ID = bugs.BUG_ID  
                           and rel."VALUE" LIKE '%{}%'
                           and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%squad:LifeCycle%'
                           and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                           'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                      FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                      WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%squad:LifeCycle%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_mgm_integration_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                           Bugzilla.profiles profiles, Bugzilla.components components, 
                           Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                           and bugs.QA_CONTACT = profiles.userid 
                           and bugs.product_id = products.id 
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%'
                           and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%Squad:integration%'
                           and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                           'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                  FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                           Bugzilla.components components, Bugzilla.bugs_release rel
                  WHERE bugs.component_id = components.id 
                          and rel."VALUE" LIKE '%{}%' 
                          and bugs.QA_CONTACT = profiles.userid 
                          and bugs.product_id = products.id 
                          and rel.BUG_ID = bugs.BUG_ID 
                          and bugs.VERSION LIKE '%{}%'
                          and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                          'MODIFIED', 'ON_DEV' ,'ON_QA') 
                          and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%Squad:integration%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_mgm_policy_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                           Bugzilla.profiles profiles, Bugzilla.components components, 
                           Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                           and bugs.QA_CONTACT = profiles.userid 
                           and bugs.product_id = products.id 
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%'
                           and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%Squad:Policy%'
                           and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                           'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                           Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                           and rel."VALUE" LIKE '%{}%' 
                           and bugs.QA_CONTACT = profiles.userid 
                           and bugs.product_id = products.id 
                           and rel.BUG_ID = bugs.BUG_ID 
                           and bugs.VERSION LIKE '%{}%'
                           and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                           'MODIFIED', 'ON_DEV', ON_QA') 
                           and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%Squad:Policy%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_mgm_ACM_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                          bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                          bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                          p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                          ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                          Bugzilla.profiles profiles, Bugzilla.components components, 
                          Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                          and bugs.QA_CONTACT = profiles.userid 
                          and bugs.product_id = products.id
                          and rel.BUG_ID = bugs.BUG_ID 
                          and rel."VALUE" LIKE '%{}%'
                          and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%Squad:ACM%'
                          and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                          'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                      FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                      WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:Management,%Squad:ACM%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_CNF_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                          bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                          bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                         p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                         ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                         Bugzilla.profiles profiles, Bugzilla.components components, 
                         Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                         and bugs.QA_CONTACT = profiles.userid 
                         and bugs.product_id = products.id 
                         and rel.BUG_ID = bugs.BUG_ID
                         and rel."VALUE" LIKE '%{}%'
                         and CF_INTERNAL_WHITEBOARD LIKE '%Telco:%CNF%'
                         and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                         'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                      FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                      WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:%CNF%' '''.format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_CNF_compute_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                           Bugzilla.profiles profiles, Bugzilla.components components, 
                           Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                           and bugs.QA_CONTACT = profiles.userid 
                           and bugs.product_id = products.id
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%'
                           and CF_INTERNAL_WHITEBOARD LIKE '%Telco:%CNF,%Squad:Compute%'
                           and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                           'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                      FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                      WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:CNF,%Squad:Compute%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_CNF_Networking_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                          p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                          ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                          Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                          and bugs.QA_CONTACT = profiles.userid 
                          and bugs.product_id = products.id 
                          and rel.BUG_ID = bugs.BUG_ID
                          and rel."VALUE" LIKE '%{}%'
                          and CF_INTERNAL_WHITEBOARD LIKE '%Telco:CNF,%Squad:Network%'
                          and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                          'MODIFIED', 'ON_QA', 'ON_DEV') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:CNF,%Squad:Network%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_CNF_Integration_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                                p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                                ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                                Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                                and bugs.QA_CONTACT = profiles.userid 
                                and bugs.product_id = products.id
                                and rel.BUG_ID = bugs.BUG_ID
                                and rel."VALUE" LIKE '%{}%'
                                and CF_INTERNAL_WHITEBOARD LIKE '%Telco:CNF,%Squad:Integration%'
                                and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                                'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:CNF,%Squad:Integration%' ''' \
            .format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_EcoSystem_backlog(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                           p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                           ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, 
                           Bugzilla.profiles profiles,
                           Bugzilla.components components, 
                           Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                           and bugs.QA_CONTACT = profiles.userid 
                           and rel.BUG_ID = bugs.BUG_ID 
                           and bugs.product_id = products.id
                           and rel."VALUE" LIKE '%{}%' 
                           and CF_INTERNAL_WHITEBOARD LIKE '%Telco:EcoSystem%'
                           and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                           'MODIFIED', 'ON_DEV', 'ON_QA') '''.format(TARGET_R)

    # If there is a target release like 4.3.0 or 4.4.0
    else:
        query = '''SELECT bugs.bug_id, bugs.short_desc, rel."VALUE", bugs.BUG_SEVERITY, 
                           bugs.BUG_STATUS, components.name, p2.REALNAME assign, p1.REALNAME qa,
                           bugs.creation_ts, bugs.CF_PM_SCORE, rel.BUG_ID
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                             p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                             ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                             Bugzilla.components components, Bugzilla.bugs_release rel
                   WHERE bugs.component_id = components.id 
                             and rel."VALUE" LIKE '%{}%' 
                             and bugs.QA_CONTACT = profiles.userid 
                             and bugs.product_id = products.id 
                             and rel.BUG_ID = bugs.BUG_ID 
                             and bugs.VERSION LIKE '%{}%'
                             and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                             'MODIFIED', 'ON_DEV', 'ON_QA') 
                             and CF_INTERNAL_WHITEBOARD LIKE '%Telco:EcoSystem%' '''.format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


''' ##################################################################################################################
                                            Risk Assesment

                                            X Regression rate
                                            X FailedQa rate
                                            X Verification rate
                                            X Verification rate weekly
                                            X Defect gap
                                            x "Bad-bugs" rate

###################################################################################################################'''


def get_new_arrivals(TARGET, weekago, now, OCP_VERSION):
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''
                SELECT bugs.bug_id
                FROM Bugzilla.bugs bugs
                WHERE bugs.CF_INTERNAL_WHITEBOARD LIKE '%Telco%'
                      and bugs.LASTDIFFED BETWEEN '%{}%' AND '%{}%' 
                      and bugs.VERSION LIKE '%{}%' '''.format(str(weekago), str(now), OCP_VERSION)
    else:
        query = '''
                SELECT bugs.bug_id
                FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                WHERE bugs.CF_INTERNAL_WHITEBOARD LIKE '%Telco%'
                      and rel.BUG_ID = bugs.BUG_ID
                      and bugs.LASTDIFFED BETWEEN '%{}%' AND '%{}%' 
                      and rel."VALUE" LIKE '%{}%'
                      and bugs.VERSION LIKE '%{}%' '''.format(TARGET, str(weekago), str(now), OCP_VERSION)

    cursor.execute(query)
    rows = cursor.fetchall()
    print(len(rows))
    return rows


def get_resolved_bugs(TARGET, weekago, now, OCP_VERSION):
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''
                SELECT bugs.bug_id
                FROM Bugzilla.bugs bugs
                WHERE bugs.CF_INTERNAL_WHITEBOARD LIKE '%Telco%'
                      and bugs.bug_status = 'ON_QA'
                      and bugs.LASTDIFFED BETWEEN '%{}%' AND '%{}%' 
                      and bugs.VERSION LIKE '%{}%' '''.format(str(weekago), str(now), OCP_VERSION)
    else:
        query = '''
                SELECT bugs.bug_id
                FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                WHERE bugs.CF_INTERNAL_WHITEBOARD LIKE '%Telco%'
                      and rel.BUG_ID = bugs.BUG_ID
                      and bugs.bug_status = 'ON_QA'
                      and bugs.LASTDIFFED BETWEEN '%{}%' AND '%{}%' 
                      and rel."VALUE" LIKE '%{}%' 
                      and bugs.VERSION LIKE '%{}%' '''.format(TARGET, str(weekago), str(now), OCP_VERSION)

    cursor.execute(query)
    rows = cursor.fetchall()
    print(len(rows))
    return rows


def get_all_regression_bugs(OCP_VERSION):
    query = '''SELECT bugs.bug_id
               FROM Bugzilla.bugs bugs, Bugzilla.keywords keywords, Bugzilla.keyworddefs keydef 
               WHERE keydef.ID=keywords.KEYWORDID 
                     and bugs.bug_id = keywords.BUG_ID 
                     and CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                     and keydef.NAME LIKE '%Regression%' 
                     and bugs.VERSION LIKE '%{}%' '''.format(OCP_VERSION)

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_all_verified_bugs(TARGET):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                       FROM Bugzilla.bugs bugs, Bugzilla.bugs_activity activity, Bugzilla.bugs_release rel
                       WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                             and activity.BUG_ID = bugs.BUG_ID
                             and rel.BUG_ID = bugs.BUG_ID
                             and activity.ADDED ='VERIFIED' 
                             and rel."VALUE" LIKE '%{}%' '''.format(TARGET_R)
    else:
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                               FROM Bugzilla.bugs bugs,Bugzilla.bugs_activity activity ,Bugzilla.bugs_release rel
                               WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                                     and rel.BUG_ID = bugs.BUG_ID
                                     and activity.BUG_ID = bugs.BUG_ID
                                     and  activity.ADDED ='VERIFIED'
                                     and rel."VALUE" LIKE '%{}%' '''.format(TARGET)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_verified_bugs(TARGET):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.BUG_ID
                   FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                   WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                         and rel.BUG_ID = bugs.BUG_ID
                         and bugs.BUG_STATUS ='VERIFIED'
                         and rel."VALUE" LIKE '%{}%' '''.format(TARGET_R)
    else:
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                           FROM Bugzilla.bugs bugs,Bugzilla.bugs_activity activity ,Bugzilla.bugs_release rel
                           WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                                 and rel.BUG_ID = bugs.BUG_ID
                                 and activity.BUG_ID = bugs.BUG_ID
                                 and activity.ADDED='VERIFIED' 
                                 and rel."VALUE" LIKE '%{}%' '''.format(TARGET)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_all_weekly_verified_bugs(TARGET, now, weekago):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.bug_id
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                              p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                              ON p2.USERID = bugs.ASSIGNED_TO,  
                              Bugzilla.profiles profiles,
                              Bugzilla.bugs_release rel
                   WHERE bugs.QA_CONTACT = profiles.userid 
                              and CF_INTERNAL_WHITEBOARD LIKE '%Telco%'
                              and bugs.BUG_STATUS= 'VERIFIED' 
                              and rel.BUG_ID = bugs.BUG_ID
                              and rel."VALUE" LIKE '%{}%'
                              and (bugs.LASTDIFFED BETWEEN '%{}%' AND '%{}%') '''\
                                  .format(TARGET_R, str(weekago), str(now))
    else:
        query = '''SELECT bugs.bug_id,bugs.short_desc, p1.REALNAME qa, p2.REALNAME assign, bugs.BUG_STATUS, 
                          bugs.BUG_SEVERITY,bugs.creation_ts, bugs.CF_PM_SCORE
                   FROM Bugzilla.bugs bugs INNER JOIN Bugzilla.profiles p1 ON
                        p1.USERID = bugs.QA_CONTACT INNER JOIN Bugzilla.profiles p2
                        ON p2.USERID = bugs.ASSIGNED_TO, Bugzilla.products products, Bugzilla.profiles profiles,
                        Bugzilla.bugs_release rel
                   WHERE keydef.ID=keywords.KEYWORDID and
                         bugs.bug_id = keywords.BUG_ID and
                         bugs.QA_CONTACT = profiles.userid
                         and rel.BUG_ID = bugs.BUG_ID
                         and bugs.product_id = products.id
                         and bugs.BUG_STATUS IN('NEW','ASSIGNED','POST',
                                        'MODIFIED', 'ON_DEV','ON_QA')
                         and CF_INTERNAL_WHITEBOARD LIKE '%Telco%' and 
                         bugs.BUG_STATUS = 'VERIFIED' and rel."VALUE" LIKE '%{}%' 
                         and bugs.LASTDIFFED BETWEEN '%{}%' AND '%{}%' '''.format(TARGET, str(weekago),
                                                                                  str(now))

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_fixed_bugs(TARGET):

    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                   FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                   WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                         and bugs.BUG_STATUS IN('VERIFIED', 'CLOSED')
                         and rel.BUG_ID = bugs.BUG_ID
                         and rel."VALUE" LIKE '%{}%' '''.format(TARGET_R)
    else:
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                           FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                           WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                                 and rel.BUG_ID = bugs.BUG_ID
                                 and bugs.BUG_STATUS IN('VERIFIED', 'CLOSED')                                 
                                 and rel."VALUE" LIKE '%{}%' '''.format(TARGET)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_failed_qa_count(TARGET):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.BUG_ID
                     FROM Bugzilla.bugs bugs, Bugzilla.bug_cf_verified c_verified, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                           and c_verified.BUG_ID = bugs.BUG_ID
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%'
                           and c_verified."VALUE" LIKE '%FailedQA%' '''.format(TARGET_R)
    else:
        query = '''SELECT activity.BUG_ID
                     FROM Bugzilla.bug_cf_verified c_verified, Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                           and c_verified.BUG_ID = bugs.BUG_ID
                           and c_verified."VALUE" LIKE '%FailedQA%'
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%' '''.format(TARGET)

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_urgent_failed_qa_count(TARGET):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.BUG_ID
                     FROM Bugzilla.bugs bugs, Bugzilla.bug_cf_verified c_verified, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                           and c_verified.BUG_ID = bugs.BUG_ID
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%'
                           and bugs.bug_severity IN('urgent', 'high')
                           and c_verified."VALUE" LIKE '%FailedQA%' '''.format(TARGET_R)
    else:
        query = '''SELECT activity.BUG_ID
                     FROM Bugzilla.bug_cf_verified c_verified, Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                           and c_verified.BUG_ID = bugs.BUG_ID
                           and c_verified."VALUE" LIKE '%FailedQA%'
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%' '''.format(TARGET)

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_ready_for_testing(TARGET):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                   FROM Bugzilla.bugs bugs, Bugzilla.keywords keywords, Bugzilla.keyworddefs keydef, 
                        Bugzilla.bugs_activity activity, Bugzilla.bugs_release rel
                   WHERE keywords.BUG_ID = bugs.BUG_ID
                         and bugs.BUG_ID = activity.BUG_ID 
                         and keydef.ID = keywords.KEYWORDID
                         and keydef.NAME = 'Reopened' 
                         and activity.ADDED = 'ON_QA'
                         and rel.BUG_ID = bugs.BUG_ID
                         and rel."VALUE" LIKE '%{}%'
                         and CF_INTERNAL_WHITEBOARD LIKE '%Telco%' '''.format(TARGET_R)
    else:
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                   FROM Bugzilla.bugs bugs, Bugzilla.keywords keywords, Bugzilla.keyworddefs keydef, 
                         Bugzilla.bugs_activity activity, Bugzilla.bugs_release rel
                   WHERE keywords.BUG_ID = bugs.BUG_ID
                         and bugs.BUG_ID = activity.BUG_ID 
                         and keydef.ID = keywords.KEYWORDID
                         and keydef.NAME = 'Reopened' 
                         and activity.ADDED = 'ON_QA'
                         and CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                         and rel."VALUE" LIKE '%{}%'
                         and rel.BUG_ID = bugs.BUG_ID
                         and c_verified.BUG_ID = bugs.BUG_ID '''.format(TARGET)

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_all_bugs_by_version(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.BUG_ID
                     FROM Bugzilla.bugs bugs
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                     and bugs.VERSION LIKE '%{}%' '''.format(OCP_VERSION)
    else:
        query = '''SELECT bugs.BUG_ID
                     FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%' 
                           and bugs.VERSION LIKE '%{}%' '''.format(TARGET, OCP_VERSION)

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_all_bugs(TARGET):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT bugs.BUG_ID
                     FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%' '''.format(TARGET_R)
    else:
        query = '''SELECT bugs.BUG_ID
                     FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%' '''.format(TARGET)

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_closed_bugs(TARGET):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                     FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%'
                           and rel.BUG_ID = bugs.BUG_ID
                           and bugs.BUG_STATUS ='CLOSED' and rel."VALUE" LIKE '%{}%' '''.format(TARGET_R)
    else:
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                     FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                     WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                           and bugs.BUG_STATUS ='CLOSED'
                           and rel.BUG_ID = bugs.BUG_ID
                           and rel."VALUE" LIKE '%{}%' '''.format(TARGET)

    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_bad_bugs_count(TARGET, OCP_VERSION):
    # If no target release were mentioned
    if TARGET == '' or TARGET == 'ALL' or TARGET == 'all':
        query = '''SELECT DISTINCT(bugs.BUG_ID)
                   FROM Bugzilla.bugs bugs
                   WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                         and bugs.RESOLUTION IN('DUPLICATE', 'NOTABUG') 
                         and bugs.VERSION LIKE '%{}%' '''.format(OCP_VERSION)
    else:
        query = '''SELECT activity.BUG_ID
                   FROM Bugzilla.bugs bugs, Bugzilla.bugs_release rel
                   WHERE CF_INTERNAL_WHITEBOARD LIKE '%Telco%' 
                         and bugs.RESOLUTION IN('DUPLICATE', 'NOTABUG')
                         and rel.BUG_ID = bugs.BUG_ID
                         and rel."VALUE" LIKE '%{}%'
                         and bugs.VERSION LIKE '%{}%' '''.format(TARGET, OCP_VERSION)
    cursor.execute(query)
    rows = cursor.fetchall()
    return rows


def get_verification_weekly_rate(TARGET):
    verified_weekly = 0

    # Run on the last <VERIFICATION_RATE_WEEKS_NUM> (weeks)
    # and check verified bugs between each week to another
    for week_num in range(VERIFICATION_RATE_WEEKS_NUM):
        # current day
        now = datetime.date.today() - datetime.timedelta(days=week_num * 7)

        # a week ago from the previous day
        weekago = now - datetime.timedelta(days=7)

        # check number of verified bugs per this week
        this_week = len(get_all_weekly_verified_bugs(TARGET, now, weekago))
        verified_weekly += this_week

    # return verification rate
    return verified_weekly / VERIFICATION_RATE_WEEKS_NUM
