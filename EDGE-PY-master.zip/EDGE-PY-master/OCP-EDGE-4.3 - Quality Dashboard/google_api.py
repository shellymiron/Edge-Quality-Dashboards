"""
API module to interact with Google spreadsheets
In order to create a new spreadsheet, share the spreadsheet with the
'client_email' in your credentials json file with write permissions.

"""
import os
import time
import gspread
import gspread_formatting as gspf
from oauth2client.service_account import ServiceAccountCredentials

# To know the start & end place of the bugs-table
TABLE_START = 'G'
TABLE_END = 'P'
COL_END = 16


class GoogleSpreadSheetAPI(object):
    """
    A class to interact with Google Spreadsheet
    """

    def __init__(self, spreadsheet_name, sheet_name):
        # use creds to create a client to interact with the Google Drive API
        scope = [
            'https://spreadsheets.google.com/feeds',
            'https://www.googleapis.com/auth/drive'
        ]
        google_api = os.path.expanduser('~/.gapi/google_api_secret.json')
        creds = ServiceAccountCredentials.from_json_keyfile_name(
            google_api, scope
        )
        client = gspread.authorize(creds)
        self.sheet = client.open(spreadsheet_name).worksheet(sheet_name)

    def update_sheet(self, row, col, value):
        """
        Updates a row:col in a given spreadsheet
        """
        self.sheet.update_cell(row, col, value)

    def print_sheet(self):
        list_of_hashes = self.sheet.get_all_records()
        print(list_of_hashes)

    def get_cell_value(self, row, col):
        return self.sheet.cell(row, col).value

    def insert_row(self, value, row_index):
        return self.sheet.insert_row(value, row_index)

    # Make border to a particular cell
    def make_border(self, row):

        # gspread-formatting - make border - up, down, left, right for the cell
        FormatCell = gspf.cellFormat(
            borders=gspf.borders(bottom=gspf.border('SOLID'),
                                 top=gspf.border('SOLID'),
                                 left=gspf.border('SOLID'),
                                 right=gspf.border('SOLID')))

        # For the whole row - make a border to the cells in this row
        gspf.format_cell_range(self.sheet, TABLE_START +
                               str(row) + ':' + TABLE_END + str(row), FormatCell)

    def clean_border(self, row):

        # gspread-formatting - make border - up, down, left, right for the cell
        FormatCell = gspf.cellFormat(
            borders=gspf.borders(bottom=gspf.border('NONE'),
                                 top=gspf.border('NONE'),
                                 left=gspf.border('NONE'),
                                 right=gspf.border('NONE')))

        # For the whole row - make a border to the cells in this row
        gspf.format_cell_range(self.sheet, TABLE_START +
                               str(row) + ':' + TABLE_END + str(row), FormatCell)

    def clean_row(self, row, start_column, end_column):

        # Clean a single row
        for x in range(start_column, end_column):
            self.update_sheet(row, x, "")

    def clean_rows(self, row, column):

        # Clean all the rows that comes after the last row with a bug
        while self.get_cell_value(row, column) != "":
            time.sleep(10)
            self.clean_border(row)
            self.clean_row(row, column, COL_END + 1)
            row += 1


    RANGE = 'DATA!G10'
    SAMPLE_SPREADSHEET_ID = '1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms'
