USER = "<YOUR_BUGZILLA_USER>@redhat.com"
PASSWORD = "<YOUR_BUGZILLA_PASSWORD>"

# For the Bugzilla reports
gmail_user = "<YOUR_MAIL>@gmail.com"
gmail_pwd = "<YOUR_PASSWORD>"
mail_to = "<YOUR_MAIL>@redhat.com"
