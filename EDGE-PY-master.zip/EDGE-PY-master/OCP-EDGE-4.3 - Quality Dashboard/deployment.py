#!/usr/bin/env python
import datetime
import time

from helpers import *

# Take current time and init the name of the spreadsheet & sheet
now = datetime.datetime.now()
g = gapi.GoogleSpreadSheetAPI(SPREADSHEET_NAME, "Telco:Deployment")
g.update_sheet(1, 1, f'Last update: {now.strftime("%Y-%m-%d %H:%M")}')

# Take sum of bugs for a current target release and update
qe_backlog = len(get_deployment_backlog(TARGET_RELEASE, VERSION))
g.update_sheet(6, 10, qe_backlog)
print('Deployment bugs = ' + str(qe_backlog))

# Sleep to ensure no exception will raise from Google API due to writes limit
time.sleep(30)

# Init
countRow = 0
row = 10
column = 7

# Take the bugs per fields - ID, DESCRIPTION, ASSIGNEE, STATUS, COMPONENT, SEVERITY AND AGING
bug_list = get_deployment_backlog(TARGET_RELEASE, VERSION)

# Sort by pm_score_rate
bug_list = sort_by_pm_score(bug_list)

# Update bugs in the table
for bug in bug_list:
    time.sleep(10)
    row = 10 + countRow

    # Make a border for all the cells in the current row
    g.make_border(row)

    column = 7
    g.update_sheet(
        row,
        column,
        (
            f'=HYPERLINK("https://bugzilla.redhat.com/show_bug'
            f'.cgi?id={bug[0]}", "{bug[0]}")'
        )
    )
    g.update_sheet(row, column + 1, bug[1])
    g.update_sheet(row, column + 2, bug[2])
    g.update_sheet(row, column + 3, bug[3])
    g.update_sheet(row, column + 4, bug[4])
    g.update_sheet(row, column + 5, bug[5])
    g.update_sheet(row, column + 6, bug[6])
    g.update_sheet(row, column + 7, bug[7])
    g.update_sheet(row, column + 8, (now - bug[8]).days)
    g.update_sheet(row, column + 9, bug[9])
    countRow = countRow + 1

time.sleep(5)
g.clean_rows(row + 1, column)
print("juju")
