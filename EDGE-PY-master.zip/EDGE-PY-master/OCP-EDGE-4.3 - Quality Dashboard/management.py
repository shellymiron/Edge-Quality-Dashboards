#!/usr/bin/env python
import datetime
import time

from helpers import *

# Take current time and init the name of the spreadsheet & sheet
now = datetime.datetime.now()
g = gapi.GoogleSpreadSheetAPI(SPREADSHEET_NAME, "Telco:Management")
g.update_sheet(1, 1, f'Last update: {now.strftime("%Y-%m-%d %H:%M")}')

# Take sum of bugs for a current target release and update
qe_backlog = len(get_management_backlog(TARGET_RELEASE, VERSION))
g.update_sheet(6, 10, qe_backlog)
print('Management bugs = ' + str(qe_backlog))

# Sleep to ensure no exception will raise from Google API due to writes limit
time.sleep(30)

# Init
countRow = 0
row = 10
column = 7

# Take the bugs per fields - ID, DESCRIPTION, QA contact, ASSIGNEE, STATUS, COMPONENT, SEVERITY AND AGING
bug_list = get_management_backlog(TARGET_RELEASE, VERSION)

# Sort by pm_score_rate
bug_list = sort_by_pm_score(bug_list)

# Update bugs in the table
for bug in bug_list:
    time.sleep(10)
    row = 10 + countRow

    # Make a border for all the cells in the current row
    g.make_border(row)

    column = 7
    g.update_sheet(
        row,
        column,
        (
            f'=HYPERLINK("https://bugzilla.redhat.com/show_bug'
            f'.cgi?id={bug[0]}", "{bug[0]}")'

            # sort by pm score & pm score field

        )
    )
    g.update_sheet(row, column + 1, bug[1])
    g.update_sheet(row, column + 2, bug[2])
    g.update_sheet(row, column + 3, bug[3])
    g.update_sheet(row, column + 4, bug[4])
    g.update_sheet(row, column + 5, bug[5])
    g.update_sheet(row, column + 6, bug[6])
    g.update_sheet(row, column + 7, bug[7])
    g.update_sheet(row, column + 8, (now - bug[8]).days)
    g.update_sheet(row, column + 9, bug[9])
    countRow = countRow + 1

time.sleep(5)
g.clean_rows(row + 1, column)
print("juju")

# Regression rate
all_bugs = len(get_all_bugs(TARGET_RELEASE))
all_regressions = len(get_all_regression_bugs(TARGET_RELEASE))
regression_rate = round((all_regressions / float(all_bugs)), 4)
g.update_sheet(10, 2, regression_rate)

# FailedQA rate
# all_failed_qa = get_all_failedqa_bugs()
# failed_qa_count = 0
# for bz in all_failed_qa:
#     failed_qa_count += str(bz.get_history_raw()).count(
#         "'removed': 'ON_QA', 'added': 'ASSIGNED'"
#     )
# failed_qa_rate = round((failed_qa_count / float(all_bugs)), 4)
# g.update_sheet(13, 2, failed_qa_rate)

# Verification rate
# all_verified = len(get_all_verified_bugs())
# all_ready_for_testing = len(get_all_ready_for_testing_bugs())
# failed_qa_rate = round((all_verified / float(all_ready_for_testing)), 4)
# g.update_sheet(16, 2, failed_qa_rate)

# Verification rate weekly
# verified_weekly = 0
# for c_from, c_to in [
#     ('-1w', 'Now'), ('-2w', '-1w'), ('-3w', '-2w'), ('-4w', '-3w'),
#     ('-5w', '-4w'), ('-6w', '-5w'), ('-7w', '-6w'), ('-8w', '-7w')
# ]:
#     this_week = len(get_verified_bugs(c_from, c_to))
#     verified_weekly += this_week
# g.update_sheet(19, 2, verified_weekly / 8)
